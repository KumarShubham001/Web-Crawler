<?php

function  spider( $base_url , $search_urls=array() ) 
{
    ini_set('max_execution_time', 0);
    ini_set('display_errors',0);

    $queue[] = $base_url;
    $done           =   array();
    $found_urls     =   array();
    while($queue) 
    {
        $link = array_shift($queue);
        if(!is_array($link)) 
        {
            $done[] = $link;

            foreach( $search_urls as $s) { if (strstr( $link , $s )) { $found_urls[] = $link; } }

            if( empty($search_urls)) { $found_urls[] = $link; }

            if(!empty($link )) 
            {

                echo "<tr>" . "<td>" . $link . "</td>" . "</tr>";

                $content =    file_get_contents( $link );

                //echo 'P:::'.$content;
                preg_match_all('~<a.*?href="(.*?)".*?>~', $content, $sublink);
                if (!in_array($sublink , $done) && !in_array($sublink , $queue)  ) 
                {
                       $queue[] = $sublink;
                }
            }
        } 
        else 
        {
            $result=array();
            $return = array();

            // flatten multi dimensional array of URLs to one dimensional.
            while(count($link)) 
            {
                $value = array_shift($link);

                if(is_array($value))
                    foreach($value as $sub)
                        $link[] = $sub;
                else
                    $return[] = $value;
            }

            // now loop over one dimensional array.
            foreach($return as $link) 
            {
                // echo 'L::'.$link;
                // url may be in form <a href.. so extract what's in the href bit.
                preg_match_all('/<a[^>]+href=([\'"])(?<href>.+?)\1[^>]*>/i', $link, $result);

                if ( isset( $result['href'][0] )) { $link = $result['href'][0]; }

                // add the new URL to the queue.
                if( (!strstr( $link , "http")) && (!in_array($base_url.$link , $done)) && (!in_array($base_url.$link , $queue)) ) 
                {
                     $queue[]=$base_url.$link;
                } 
                else 
                {
                    if ( (strstr( $link , $base_url  ))  && (!in_array($base_url.$link , $done)) && (!in_array($base_url.$link , $queue)) ) 
                    {
                         $queue[] = $link;
                    }
                }
            }
        }
    }


    return $found_urls;
}

?>

<!DOCTYPE HTML>
<html lang="en" class="no-js">
<head>

    <title>Project_018</title>
    
    <meta charset="utf-8" />
    <meta http-equiv="content-type" content="text/html" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- shortcut icon -->
    <link rel="shortcut icon" href="" />

    <!-- links for css designs --><link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"  /><link href="css/style.css" rel="stylesheet" type="text/css"  />
    
    <!-- link for font awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
    
</head>
<body>
    <div class="se-pre-con"></div>

    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-12">
                <h1 class="text-center text-primary header text-header">Enter the website to be crawlled</h1>

                <form class="form form-inline" action="" method="POST">
                    <p class="text-center"><input type="url" class="form-control" maxlength="30" placeholder="http://" name="input-url"><button class="btn btn-success" type="submit" name="submit-but">Crawl</button></p>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <table class="table table-bordered table-responsive table-condensed">
<?php

if (isset($_POST['submit-but'])) 
{
    $base_url       =   $_POST['input-url'];
    $search_urls    =   array(  $base_url.'acatalog/' );
    $done = spider( $base_url  , $search_urls  );    

    //
    // RESULT
    //
    //
    echo '<br /><br />';
    echo 'List of links crawlled are:';
    foreach(  $done as $r )  
    {
        echo 'URL:::'.$r.'<br />';
    }
}

?>

                </table>
            </div>
        </div>
    </div>

    <!-- links for js scripts --><script src="js/jquery-3.2.1.min.js" type="text/javascript"></script><script src="js/bootstrap.min.js" type="text/javascript"></script><script src="js/app.js" type="text/javascript"></script>
</body>
</html>